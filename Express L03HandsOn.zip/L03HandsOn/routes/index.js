var express = require('express');
var router = express.Router();
var storyPart = require('../models/storyline');

/* GET home page. */
router.get('/storyPart/:beginning', '/storyPart/:middle', '/storyPart/:end', function(req, res, next) {
  let storyPart = storyline.story.find(storys => {
    return storys.storyPart === parseInt(req.params.storyPart);
  })
  res.render('index', { storyPart });
});

module.exports = router;
